package com.ch.surya.productmanagement.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.surya.productmanagement.Model.Product;
import com.ch.surya.productmanagement.Model.Stock;
import com.ch.surya.productmanagement.repository.StockRepository;

@Service
public class StockService {
    @Autowired
    private StockRepository stockRepository;

    public List<Stock> getAllStocks() {
        return stockRepository.findAll();
    }

    public Stock getStockByProduct(Product product) {
        return stockRepository.findByProduct(product);
    }

    public Stock createStock(Stock stock) {
        return stockRepository.save(stock);
    }

    public Stock updateStock(Long id, Stock stock) {
        Optional<Stock> optionalStock = stockRepository.findById(id);
        if (optionalStock.isPresent()) {
            Stock existingStock = optionalStock.get();
            existingStock.setProduct(stock.getProduct());
            existingStock.setStock(stock.getStock());
            return stockRepository.save(existingStock);
        }
        return null;
    }

    public void deleteStock(Long id) {
        stockRepository.deleteById(id);
    }
}