package com.ch.surya.productmanagement.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.surya.productmanagement.Model.Order;
import com.ch.surya.productmanagement.Model.OrderDetail;
import com.ch.surya.productmanagement.Model.Product;
import com.ch.surya.productmanagement.Model.login.User;
import com.ch.surya.productmanagement.repository.OrderRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class OrderService {

    @Autowired
    private OrderRepository orderRepository;

    @Autowired
    private ProductService productService;

    @Autowired
    private UserService userService;

    public List<Order> getAllOrders() {
        return orderRepository.findAll();
    }

    public Order getOrderById(Long id) {
        return orderRepository.findById(id).orElse(null);
    }

    public Order createOrder(Order order) {
        List<OrderDetail> orderDetails = new ArrayList<>();
        for (OrderDetail orderDetail : order.getOrderDetails()) {
            Product product = productService.getProductById(orderDetail.getProduct().getId());
            if (product == null) {
                throw new EntityNotFoundException("Product not found with id " + orderDetail.getProduct().getId());
            }
            OrderDetail newOrderDetail = new OrderDetail();
            newOrderDetail.setQty(orderDetail.getQty());
            newOrderDetail.setPrice(orderDetail.getPrice());
            newOrderDetail.setProduct(product);
            newOrderDetail.setOrder(order);
            orderDetails.add(newOrderDetail);
        }
        order.setOrderDetails(new HashSet<>(orderDetails));
        User user = userService.getUserById(order.getUser().getId());
        if (user == null) {
            throw new EntityNotFoundException("User not found with id " + order.getUser().getId());
        }
        order.setUser(user);
        return orderRepository.save(order);
    }

    public Order updateOrder(Long id, Order order) {
        Order existingOrder = orderRepository.findById(id).orElse(null);
        if (existingOrder != null) {
            List<OrderDetail> orderDetails = new ArrayList<>();
            for (OrderDetail orderDetail : order.getOrderDetails()) {
                Product product = productService.getProductById(orderDetail.getProduct().getId());
                if (product == null) {
                    throw new EntityNotFoundException("Product not found with id " + orderDetail.getProduct().getId());
                }
                OrderDetail newOrderDetail = new OrderDetail();
                newOrderDetail.setId(orderDetail.getId());
                newOrderDetail.setQty(orderDetail.getQty());
                newOrderDetail.setPrice(orderDetail.getPrice());
                newOrderDetail.setProduct(product);
                newOrderDetail.setOrder(existingOrder);
                orderDetails.add(newOrderDetail);
            }
            existingOrder.setOrderDetails(new HashSet<>(orderDetails));
            User user = userService.getUserById(order.getUser().getId());
            if (user == null) {
                throw new EntityNotFoundException("User not found with id " + order.getUser().getId());
            }
            existingOrder.setUser(user);
            return orderRepository.save(existingOrder);
        }
        return null;
    }

    public void deleteOrder(Long id) {
        orderRepository.deleteById(id);
    }
}