package com.ch.surya.productmanagement.Model.login;

public enum ERole {
  ROLE_USER,
  ROLE_ADMIN
}
