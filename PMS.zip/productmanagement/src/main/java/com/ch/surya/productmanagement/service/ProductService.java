package com.ch.surya.productmanagement.service;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.surya.productmanagement.Model.Brand;
import com.ch.surya.productmanagement.Model.Category;
import com.ch.surya.productmanagement.Model.Product;
import com.ch.surya.productmanagement.repository.ProductRepository;

import jakarta.persistence.EntityNotFoundException;

@Service
public class ProductService {

    @Autowired
    private ProductRepository productRepository;

    @Autowired
    private CategoryService categoryService;

    @Autowired
    private BrandService brandService;

    public List<Product> getAllProducts() {
        return productRepository.findAll();
    }

    public Product getProductById(Long id) {
        return productRepository.findById(id).orElse(null);
    }

    public Product createProduct(Product product) {
        Category category = categoryService.getCategoryById(product.getCategory().getId());
        if (category == null) {
            throw new EntityNotFoundException("Category not found with id " + product.getCategory().getId());
        }
        List<Brand> brands = new ArrayList<>();
        for (Brand brand : product.getBrands()) {
            Long brandId = brand.getId();
            Brand existingBrand = brandService.getBrandById(brandId);
            if (existingBrand == null) {
                throw new EntityNotFoundException("Brand not found with id " + brandId);
            }
            brands.add(existingBrand);
        }
        product.setCategory(category);
        product.setBrands(new HashSet<>(brands));
        return productRepository.save(product);
    }

    public Product updateProduct(Long id, Product product) {
        Product existingProduct = productRepository.findById(id).orElse(null);
        if (existingProduct != null) {
            Category category = categoryService.getCategoryById(product.getCategory().getId());
            if (category == null) {
                throw new EntityNotFoundException("Category not found with id " + product.getCategory().getId());
            }
            existingProduct.setProductName(product.getProductName());
            existingProduct.setDescription(product.getDescription());
            existingProduct.setStock(product.getStock());
            existingProduct.setMrp(product.getMrp());
            existingProduct.setSalePrice(product.getSalePrice());
            existingProduct.setCategory(category);
            List<Brand> brands = new ArrayList<>();
            for (Brand brand : product.getBrands()) {
                Long brandId = brand.getId();
                Brand existingBrand = brandService.getBrandById(brandId);
                if (existingBrand == null) {
                    throw new EntityNotFoundException("Brand not found with id " + brandId);
                }
                brands.add(existingBrand);
            }
            existingProduct.setBrands(new HashSet<>(brands));
            return productRepository.save(existingProduct);
        }
        return null;
    }

    public void deleteProduct(Long id) {
        productRepository.deleteById(id);
    }
}