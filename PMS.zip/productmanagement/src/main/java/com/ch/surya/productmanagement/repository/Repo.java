package com.ch.surya.productmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ch.surya.productmanagement.Model.login.User;



@Repository
public interface Repo extends JpaRepository<User, Long> {

	User findByUsername(String username);

}
