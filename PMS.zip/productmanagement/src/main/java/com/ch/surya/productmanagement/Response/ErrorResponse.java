package com.ch.surya.productmanagement.Response;

public class ErrorResponse {

}
