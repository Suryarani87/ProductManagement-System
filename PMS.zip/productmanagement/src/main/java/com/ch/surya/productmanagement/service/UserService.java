package com.ch.surya.productmanagement.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ch.surya.productmanagement.Model.login.User;
import com.ch.surya.productmanagement.repository.Repo;

@Service
public class UserService {

    @Autowired
    private Repo userRepository;

    public String registerUser(User user) {
        userRepository.save(user);
        return "User registered successfully!";
    }

    public String loginUser(String username, String password) {
    	User user = userRepository.findByUsername(username);
        if (user != null && user.getPassword().equals(password)) {
            return "Login successful!";
        } else {
            return "Invalid credentials!";
        }
    }

	public User getUserById(Long id) {
		return userRepository.findById(id).orElse(null);
	}
}
