package com.ch.surya.productmanagement.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.ch.surya.productmanagement.Model.Brand;
import com.ch.surya.productmanagement.Response.ErrorResponseDto;
import com.ch.surya.productmanagement.service.BrandService;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.tags.Tag;
@Tag(
        name = "CRUD REST APIs for Brands",
        description = "CRUD REST APIs in PMS to CREATE, UPDATE, FETCH AND DELETE brand details"
)
@RestController
@RequestMapping("/api/v1/brand")
public class BrandController {

    @Autowired
    private BrandService brandService;
    @Operation(
            summary = "Fetch All Brands REST API",
            description = "REST API to Fetch All Brands inside Brands"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "201",
                    description = "HTTP Status Fetched"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "HTTP Status Internal Server Error",
                    content = @Content(
                            schema = @Schema(implementation = ErrorResponseDto.class)
                    )
            )
    }
    )
    @GetMapping("/fetchAllBrand")
    @PreAuthorize("hasRole('USER')")
    public List<Brand> getAllBrands() {
        return brandService.getAllBrands();
    }
    @Operation(
            summary = "Fetch brand by ID REST API",
            description = "REST API to Fetch brand by ID inside Brands"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "201",
                    description = "HTTP Status FETCHED"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "HTTP Status Internal Server Error",
                    content = @Content(
                            schema = @Schema(implementation = ErrorResponseDto.class)
                    )
            )
    }
    )
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('USER')")
    public Brand getBrandById(@PathVariable Long id) {
        return brandService.getBrandById(id);
    }
    @Operation(
            summary = "Create Brand REST API",
            description = "REST API to create new Brand inside PMS"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "201",
                    description = "HTTP Status CREATED"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "HTTP Status Internal Server Error",
                    content = @Content(
                            schema = @Schema(implementation = ErrorResponseDto.class)
                    )
            )
    }
    )
    @PostMapping("/createBrand")
    @PreAuthorize("hasRole('USER')")
    public Brand createBrand(@RequestBody Brand brand) {
        return brandService.createBrand(brand);
    }
    @Operation(
            summary = "Update Brand REST API",
            description = "REST API to Update Brand inside PMS"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "201",
                    description = "HTTP Status UPDATED"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "HTTP Status Internal Server Error",
                    content = @Content(
                            schema = @Schema(implementation = ErrorResponseDto.class)
                    )
            )
    }
    )
    @PutMapping("/{id}")
    public Brand updateBrand(@PathVariable Long id, @RequestBody Brand brand) {
        return brandService.updateBrand(id, brand);
    }
    @Operation(
            summary = "Delete Brand by ID REST API",
            description = "REST API to delete brand  inside PMS-Brand"
    )
    @ApiResponses({
            @ApiResponse(
                    responseCode = "201",
                    description = "HTTP Status CREATED"
            ),
            @ApiResponse(
                    responseCode = "500",
                    description = "HTTP Status Internal Server Error",
                    content = @Content(
                            schema = @Schema(implementation = ErrorResponseDto.class)
                    )
            )
    }
    )
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('USER')")
    public void deleteBrand(@PathVariable Long id) {
        brandService.deleteBrand(id);
    }
}