package com.ch.surya.productmanagement.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.ch.surya.productmanagement.Model.Product;
import com.ch.surya.productmanagement.Model.Stock;

@Repository
public interface StockRepository extends JpaRepository<Stock, Long> {
    Stock findByProduct(Product product);
}